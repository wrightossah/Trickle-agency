function App() {
    const [isAuthenticated, setIsAuthenticated] = React.useState(false);
    const [currentPage, setCurrentPage] = React.useState('dashboard');
    const [isLoading, setIsLoading] = React.useState(true);
    const [hasSubscription, setHasSubscription] = React.useState(true);
    const [isSidebarOpen, setIsSidebarOpen] = React.useState(false);

    React.useEffect(() => {
        const verifyAuth = async () => {
            try {
                const auth = await checkAuth();
                setIsAuthenticated(auth);
                
                if (auth) {
                    try {
                        const subscribed = await checkSubscriptionStatus();
                        setHasSubscription(subscribed);
                    } catch (subError) {
                        reportError(subError);
                        setHasSubscription(true);
                    }
                }
            } catch (error) {
                reportError(error);
                setIsAuthenticated(false);
                setHasSubscription(true);
            } finally {
                setIsLoading(false);
            }
        };
        verifyAuth();
    }, []);

    const handlePageChange = (page) => {
        setCurrentPage(page);
        window.history.pushState({}, '', `/${page}`);
    };

    React.useEffect(() => {
        const handlePopState = () => {
            const path = window.location.pathname.substring(1) || 'dashboard';
            setCurrentPage(path);
        };

        window.addEventListener('popstate', handlePopState);
        return () => window.removeEventListener('popstate', handlePopState);
    }, []);

    // Handle window resize
    React.useEffect(() => {
        const handleResize = () => {
            if (window.innerWidth >= 768) {
                setIsSidebarOpen(false);
            }
        };

        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    if (isLoading) {
        return (
            <div className="flex items-center justify-center min-h-screen">
                <i className="fas fa-spinner fa-spin text-3xl text-blue-600"></i>
            </div>
        );
    }

    // Show landing page for non-authenticated users on root path
    if (!isAuthenticated && window.location.pathname === '/') {
        return <LandingPage />;
    }

    // Show auth page for non-authenticated users
    if (!isAuthenticated) {
        return <AuthPage />;
    }

    return (
        <div className="app-container" data-name="app">
            <Sidebar
                currentPage={currentPage}
                onPageChange={handlePageChange}
                isOpen={isSidebarOpen}
                onClose={() => setIsSidebarOpen(false)}
            />
            <Header
                title={currentPage.charAt(0).toUpperCase() + currentPage.slice(1)}
                onMenuClick={() => setIsSidebarOpen(true)}
            />
            <main className="content-area">
                {currentPage === 'dashboard' && <DashboardPage />}
                {currentPage === 'clients' && <ClientsPage />}
                {currentPage === 'subscription' && <SubscriptionPage />}
            </main>
        </div>
    );
}

const rootElement = document.getElementById('root');
const root = ReactDOM.createRoot(rootElement);
root.render(<App />);
