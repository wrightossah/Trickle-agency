function DashboardPage() {
    return (
        <div data-name="dashboard-page">
            <Header title="Dashboard" />
            <Dashboard />
        </div>
    );
}
