function ClientsPage() {
    return (
        <div data-name="clients-page">
            <Header title="Clients" />
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                    <ClientList />
                </div>
                <div>
                    <ClientForm />
                </div>
            </div>
        </div>
    );
}
