function SubscriptionPage() {
    return (
        <div data-name="subscription-page">
            <Header title="Subscription" />
            <SubscriptionForm />
        </div>
    );
}
