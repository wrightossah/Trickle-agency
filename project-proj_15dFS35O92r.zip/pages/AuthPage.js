function AuthPage() {
    const [currentForm, setCurrentForm] = React.useState('login');
    const resetToken = new URLSearchParams(window.location.search).get('token');

    if (resetToken) {
        return <ResetPasswordForm token={resetToken} />;
    }

    return (
        <div className="auth-container" data-name="auth-page">
            {currentForm === 'login' && <LoginForm onSwitchForm={setCurrentForm} />}
            {currentForm === 'signup' && <SignupForm onSwitchForm={setCurrentForm} />}
            {currentForm === 'forgot-password' && <ForgotPasswordForm onSwitchForm={setCurrentForm} />}
        </div>
    );
}
