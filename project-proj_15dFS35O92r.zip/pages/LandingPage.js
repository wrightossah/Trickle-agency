function LandingPage() {
    return (
        <div data-name="landing-page">
            <HeroSection />
            <FeaturesSection />
            <TestimonialsSection />
            <PricingSection />
            <CtaSection />
            <Footer />
        </div>
    );
}
