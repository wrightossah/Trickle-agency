function ViewClientModal({ client, onClose }) {
    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" data-name="view-client-modal">
            <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
                <div className="flex justify-between items-center mb-6">
                    <h2 className="text-2xl font-bold">Client Details</h2>
                    <button
                        onClick={onClose}
                        className="text-gray-500 hover:text-gray-700"
                    >
                        <i className="fas fa-times"></i>
                    </button>
                </div>

                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <h3 className="font-semibold">Basic Information</h3>
                        <p><span className="text-gray-600">Name:</span> {client.objectData.name}</p>
                        <p><span className="text-gray-600">Phone:</span> {client.objectData.phone}</p>
                        <p><span className="text-gray-600">Email:</span> {client.objectData.email}</p>
                        <p><span className="text-gray-600">Address:</span> {client.objectData.address}</p>
                    </div>

                    <div>
                        <h3 className="font-semibold">Policy Information</h3>
                        <p><span className="text-gray-600">Policy Type:</span> {client.objectData.policyType}</p>
                        <p><span className="text-gray-600">Policy Number:</span> {client.objectData.policyNumber}</p>
                        <p><span className="text-gray-600">Inception Date:</span> {new Date(client.objectData.inceptionDate).toLocaleDateString()}</p>
                        <p><span className="text-gray-600">Expiry Date:</span> {new Date(client.objectData.expiryDate).toLocaleDateString()}</p>
                        <p><span className="text-gray-600">Premium Amount:</span> {client.objectData.premiumAmount}</p>
                    </div>

                    {client.objectData.policyType === 'Auto/Motor' && (
                        <div className="col-span-2">
                            <h3 className="font-semibold mt-4">Vehicle Information</h3>
                            <div className="grid grid-cols-2 gap-4">
                                <p><span className="text-gray-600">Vehicle Number:</span> {client.objectData.vehicleNumber}</p>
                                <p><span className="text-gray-600">Make:</span> {client.objectData.vehicleMake}</p>
                                <p><span className="text-gray-600">Type:</span> {client.objectData.vehicleType}</p>
                                <p><span className="text-gray-600">Chassis Number:</span> {client.objectData.chassisNumber}</p>
                                <p><span className="text-gray-600">Color:</span> {client.objectData.vehicleColor}</p>
                                <p><span className="text-gray-600">CC/HP:</span> {client.objectData.ccHP}</p>
                                <p><span className="text-gray-600">Value:</span> {client.objectData.vehicleCurrency} {client.objectData.vehicleValue}</p>
                            </div>
                        </div>
                    )}
                </div>

                <div className="mt-6 flex justify-end">
                    <button
                        onClick={onClose}
                        className="px-4 py-2 bg-gray-600 text-white rounded hover:bg-gray-700"
                    >
                        Close
                    </button>
                </div>
            </div>
        </div>
    );
}
