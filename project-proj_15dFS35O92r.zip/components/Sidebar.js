function Sidebar({ currentPage, onPageChange, isOpen, onClose }) {
    const menuItems = [
        { id: 'dashboard', icon: 'fa-chart-line', label: 'Dashboard' },
        { id: 'clients', icon: 'fa-users', label: 'Clients' },
        { id: 'subscription', icon: 'fa-credit-card', label: 'Subscription' }
    ];

    const sidebarClasses = `fixed h-full bg-gray-800 text-white p-4 transition-transform duration-300 ease-in-out z-50 
        ${isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}
        md:w-64 w-3/4`;

    return (
        <div data-name="sidebar-wrapper">
            {/* Mobile Overlay */}
            <div 
                className={`mobile-menu-overlay ${isOpen ? 'active' : ''}`}
                onClick={onClose}
                data-name="mobile-overlay"
            ></div>

            {/* Sidebar */}
            <div className={sidebarClasses} data-name="sidebar">
                <div className="flex justify-between items-center mb-8">
                    <div className="text-2xl font-bold" data-name="logo">WRIGHT AGENCYAPP</div>
                    <button
                        onClick={onClose}
                        className="md:hidden text-white hover:text-gray-300"
                        data-name="close-sidebar"
                    >
                        <i className="fas fa-times"></i>
                    </button>
                </div>
                <nav>
                    <ul>
                        {menuItems.map(item => (
                            <li key={item.id} className="mb-4">
                                <button
                                    onClick={() => {
                                        onPageChange(item.id);
                                        onClose();
                                    }}
                                    className={`flex items-center w-full text-left px-4 py-2 rounded transition-colors ${
                                        currentPage === item.id
                                            ? 'bg-blue-600 text-white'
                                            : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                                    }`}
                                    data-name={`${item.id}-link`}
                                >
                                    <i className={`fas ${item.icon} mr-3`}></i>
                                    {item.label}
                                </button>
                            </li>
                        ))}
                    </ul>
                </nav>
            </div>
        </div>
    );
}
