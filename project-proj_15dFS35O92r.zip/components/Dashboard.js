function Dashboard() {
    const [stats, setStats] = React.useState({
        totalClients: 0,
        activePolices: 0,
        expiringSoon: 0
    });
    const [isReportDialogOpen, setIsReportDialogOpen] = React.useState(false);
    const [isAddClientModalOpen, setIsAddClientModalOpen] = React.useState(false);
    const [isClientListOpen, setIsClientListOpen] = React.useState(false);
    const [subscriptionEndDate, setSubscriptionEndDate] = React.useState(null);
    const [isProcessingPayment, setIsProcessingPayment] = React.useState(false);
    const [userEmail, setUserEmail] = React.useState('');

    const fetchStats = async () => {
        try {
            const clients = await trickleListObjects('clients', 1000, true);
            
            // Initialize dummy clients if no clients exist
            if (clients.items.length === 0) {
                await initializeDummyClients();
                // Fetch clients again after initialization
                clients = await trickleListObjects('clients', 1000, true);
            }

            const now = new Date();
            const thirtyDaysFromNow = new Date(now.setDate(now.getDate() + 30));
            
            setStats({
                totalClients: clients.items.length,
                activePolices: clients.items.filter(c => new Date(c.objectData.expiryDate) > now).length,
                expiringSoon: clients.items.filter(c => {
                    const expiryDate = new Date(c.objectData.expiryDate);
                    return expiryDate > now && expiryDate <= thirtyDaysFromNow;
                }).length
            });

            // Fetch user data
            const user = await getCurrentUser();
            if (user) {
                if (user.objectData.subscriptionEnd) {
                    setSubscriptionEndDate(new Date(user.objectData.subscriptionEnd));
                }
                if (user.objectData.email) {
                    setUserEmail(user.objectData.email);
                }
            }
        } catch (error) {
            reportError(error);
        }
    };

    React.useEffect(() => {
        fetchStats();
    }, []);

    const handlePaystackSuccessAction = async (reference) => {
        try {
            const user = await getCurrentUser();
            if (!user) {
                throw new Error('User not found');
            }

            await trickleCreateObject('subscriptions', {
                userId: user.objectId,
                months: 1,
                amount: 20,
                reference: reference,
                startDate: new Date().toISOString(),
                endDate: getSubscriptionEndDate(1)
            });

            await updateUserSubscription(user.objectId, {
                isSubscribed: true,
                subscriptionEnd: getSubscriptionEndDate(1)
            });

            window.location.reload();
        } catch (error) {
            reportError(error);
            alert('Failed to update subscription. Please contact support.');
        }
    };

    const handleQuickPayment = async () => {
        if (!userEmail) {
            alert('User email not found. Please contact support.');
            return;
        }

        setIsProcessingPayment(true);

        try {
            if (!window.PaystackPop) {
                throw new Error('Paystack not initialized. Please refresh the page.');
            }

            const handler = window.PaystackPop.setup({
                key: 'pk_test_b6a8830d043f2d7420be7f9275209ca34535cf83',
                email: userEmail,
                amount: 2000,
                currency: 'GHS',
                channels: ['mobile_money', 'ussd'],
                payment_options: true,
                mobile_money: {
                    provider: 'mtn',
                    phone: ''
                },
                ref: 'sub_' + Date.now() + '_' + Math.floor((Math.random() * 1000000) + 1),
                label: 'Monthly Subscription',
                callback: async function(response) {
                    try {
                        if (response.status === 'success') {
                            await handlePaystackSuccessAction(response.reference);
                        } else {
                            throw new Error('Payment was not successful');
                        }
                    } catch (error) {
                        reportError(error);
                        alert('Payment verification failed. Please contact support.');
                    }
                },
                onClose: function() {
                    setIsProcessingPayment(false);
                }
            });

            handler.openIframe();
        } catch (error) {
            reportError(error);
            alert(error.message || 'Payment initialization failed. Please try again.');
            setIsProcessingPayment(false);
        }
    };

    const handleAddClientSuccess = () => {
        fetchStats();
    };

    return (
        <div data-name="dashboard">
            <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
                <div>
                    <h2 className="text-2xl font-semibold">Dashboard Overview</h2>
                    {subscriptionEndDate && (
                        <p className="text-gray-600">
                            Subscription ends: {subscriptionEndDate.toLocaleDateString()}
                        </p>
                    )}
                </div>
                <div className="flex gap-4 flex-wrap justify-center">
                    <button
                        onClick={() => setIsAddClientModalOpen(true)}
                        className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 flex items-center"
                        data-name="add-client-btn"
                    >
                        <i className="fas fa-user-plus mr-2"></i>
                        Add Client
                    </button>
                    <button
                        onClick={() => setIsClientListOpen(true)}
                        className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 flex items-center"
                        data-name="view-clients-btn"
                    >
                        <i className="fas fa-users mr-2"></i>
                        View Clients
                    </button>
                    <button
                        onClick={handleQuickPayment}
                        className="bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700 flex items-center disabled:opacity-50"
                        disabled={isProcessingPayment}
                        data-name="pay-now-btn"
                    >
                        {isProcessingPayment ? (
                            <span className="flex items-center">
                                <i className="fas fa-spinner fa-spin mr-2"></i>
                                Processing...
                            </span>
                        ) : (
                            <span className="flex items-center">
                                <i className="fas fa-credit-card mr-2"></i>
                                Pay Now
                            </span>
                        )}
                    </button>
                    <button
                        onClick={() => setIsReportDialogOpen(true)}
                        className="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700 flex items-center"
                        data-name="generate-report-btn"
                    >
                        <i className="fas fa-file-pdf mr-2"></i>
                        Generate Report
                    </button>
                </div>
            </div>
            <div className="stats-grid">
                <div className="stat-card" data-name="total-clients">
                    <h3 className="text-gray-500">Total Clients</h3>
                    <p className="text-3xl font-bold">{stats.totalClients}</p>
                </div>
                <div className="stat-card" data-name="active-policies">
                    <h3 className="text-gray-500">Active Policies</h3>
                    <p className="text-3xl font-bold">{stats.activePolices}</p>
                </div>
                <div className="stat-card" data-name="expiring-soon">
                    <h3 className="text-gray-500">Policies Expiring Soon</h3>
                    <p className="text-3xl font-bold">{stats.expiringSoon}</p>
                </div>
            </div>
            <SalesChart />
            <ReportDialog
                isOpen={isReportDialogOpen}
                onClose={() => setIsReportDialogOpen(false)}
            />
            <AddClientModal
                isOpen={isAddClientModalOpen}
                onClose={() => setIsAddClientModalOpen(false)}
                onSuccess={handleAddClientSuccess}
            />
            {isClientListOpen && (
                <div className="fixed inset-0 bg-black bg-opacity-50 z-50 overflow-y-auto" data-name="client-list-modal">
                    <div className="min-h-screen px-4 py-6">
                        <div className="relative bg-white rounded-lg shadow-xl max-w-7xl mx-auto">
                            <div className="flex justify-between items-center p-4 border-b">
                                <h2 className="text-2xl font-bold">Client List</h2>
                                <button
                                    onClick={() => setIsClientListOpen(false)}
                                    className="text-gray-500 hover:text-gray-700"
                                >
                                    <i className="fas fa-times"></i>
                                </button>
                            </div>
                            <div className="p-4">
                                <ClientList />
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}
