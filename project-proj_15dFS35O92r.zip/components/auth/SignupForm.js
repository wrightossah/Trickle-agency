function SignupForm({ onSwitchForm }) {
    const [formData, setFormData] = React.useState({
        name: '',
        email: '',
        password: '',
        confirmPassword: ''
    });
    const [error, setError] = React.useState('');
    const [isLoading, setIsLoading] = React.useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (formData.password !== formData.confirmPassword) {
            setError("Passwords don't match");
            return;
        }

        setError('');
        setIsLoading(true);

        try {
            // Check if user already exists
            const existingUsers = await trickleListObjects('users', 100, true);
            const userExists = existingUsers.items.some(user => 
                user.objectData.email === formData.email
            );

            if (userExists) {
                setError('Email already registered');
                return;
            }

            // Create new user
            await trickleCreateObject('users', {
                name: formData.name,
                email: formData.email,
                password: formData.password,
                isSubscribed: false,
                createdAt: new Date().toISOString()
            });

            // Switch to login form
            onSwitchForm('login');
        } catch (error) {
            reportError(error);
            setError('Registration failed. Please try again.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="auth-card" data-name="signup-form">
            <div className="auth-header">
                <h1 className="text-2xl font-bold">Create Account</h1>
                <p className="text-gray-600">Sign up for a new account</p>
            </div>
            {error && (
                <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4" role="alert" data-name="error-message">
                    {error}
                </div>
            )}
            <form onSubmit={handleSubmit} className="auth-form">
                <div>
                    <label className="block text-gray-700 mb-2">Name</label>
                    <input
                        type="text"
                        value={formData.name}
                        onChange={(e) => setFormData({...formData, name: e.target.value})}
                        className="w-full p-2 border rounded"
                        required
                        disabled={isLoading}
                        data-name="name-input"
                    />
                </div>
                <div>
                    <label className="block text-gray-700 mb-2">Email</label>
                    <input
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({...formData, email: e.target.value})}
                        className="w-full p-2 border rounded"
                        required
                        disabled={isLoading}
                        data-name="email-input"
                    />
                </div>
                <div>
                    <label className="block text-gray-700 mb-2">Password</label>
                    <input
                        type="password"
                        value={formData.password}
                        onChange={(e) => setFormData({...formData, password: e.target.value})}
                        className="w-full p-2 border rounded"
                        required
                        disabled={isLoading}
                        data-name="password-input"
                    />
                </div>
                <div>
                    <label className="block text-gray-700 mb-2">Confirm Password</label>
                    <input
                        type="password"
                        value={formData.confirmPassword}
                        onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})}
                        className="w-full p-2 border rounded"
                        required
                        disabled={isLoading}
                        data-name="confirm-password-input"
                    />
                </div>
                <button
                    type="submit"
                    className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 disabled:opacity-50"
                    disabled={isLoading}
                    data-name="signup-btn"
                >
                    {isLoading ? (
                        <span className="flex items-center justify-center">
                            <i className="fas fa-spinner fa-spin mr-2"></i>
                            Creating account...
                        </span>
                    ) : (
                        'Sign Up'
                    )}
                </button>
            </form>
            <div className="auth-links">
                <p>
                    Already have an account?{' '}
                    <button
                        onClick={() => onSwitchForm('login')}
                        className="text-blue-600 hover:underline"
                        disabled={isLoading}
                        data-name="login-link"
                    >
                        Sign In
                    </button>
                </p>
            </div>
        </div>
    );
}
