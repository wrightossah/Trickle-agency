function ForgotPasswordForm({ onSwitchForm }) {
    const [email, setEmail] = React.useState('');
    const [isSent, setIsSent] = React.useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await trickleCreateObject('password-reset-requests', { email });
            setIsSent(true);
        } catch (error) {
            reportError(error);
        }
    };

    return (
        <div className="auth-card" data-name="forgot-password-form">
            <div className="auth-header">
                <h1 className="text-2xl font-bold">Reset Password</h1>
                <p className="text-gray-600">Enter your email to reset password</p>
            </div>
            {!isSent ? (
                <form onSubmit={handleSubmit} className="auth-form">
                    <div>
                        <label className="block text-gray-700 mb-2">Email</label>
                        <input
                            type="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="w-full p-2 border rounded"
                            required
                            data-name="email-input"
                        />
                    </div>
                    <button
                        type="submit"
                        className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700"
                        data-name="reset-btn"
                    >
                        Send Reset Link
                    </button>
                </form>
            ) : (
                <div className="text-center text-green-600 mb-4">
                    Reset link has been sent to your email
                </div>
            )}
            <div className="auth-links">
                <button
                    onClick={() => onSwitchForm('login')}
                    className="text-blue-600 hover:underline"
                    data-name="back-to-login"
                >
                    Back to Login
                </button>
            </div>
        </div>
    );
}
