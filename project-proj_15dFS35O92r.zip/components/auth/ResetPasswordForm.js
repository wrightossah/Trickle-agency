function ResetPasswordForm({ token }) {
    const [formData, setFormData] = React.useState({
        password: '',
        confirmPassword: ''
    });
    const [isReset, setIsReset] = React.useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (formData.password !== formData.confirmPassword) {
            alert("Passwords don't match");
            return;
        }
        try {
            await trickleUpdateObject('password-reset-requests', token, {
                newPassword: formData.password
            });
            setIsReset(true);
        } catch (error) {
            reportError(error);
        }
    };

    return (
        <div className="auth-card" data-name="reset-password-form">
            <div className="auth-header">
                <h1 className="text-2xl font-bold">Set New Password</h1>
                <p className="text-gray-600">Enter your new password</p>
            </div>
            {!isReset ? (
                <form onSubmit={handleSubmit} className="auth-form">
                    <div>
                        <label className="block text-gray-700 mb-2">New Password</label>
                        <input
                            type="password"
                            value={formData.password}
                            onChange={(e) => setFormData({...formData, password: e.target.value})}
                            className="w-full p-2 border rounded"
                            required
                            data-name="password-input"
                        />
                    </div>
                    <div>
                        <label className="block text-gray-700 mb-2">Confirm New Password</label>
                        <input
                            type="password"
                            value={formData.confirmPassword}
                            onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})}
                            className="w-full p-2 border rounded"
                            required
                            data-name="confirm-password-input"
                        />
                    </div>
                    <button
                        type="submit"
                        className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700"
                        data-name="reset-btn"
                    >
                        Reset Password
                    </button>
                </form>
            ) : (
                <div className="text-center">
                    <p className="text-green-600 mb-4">Password has been reset successfully</p>
                    <a
                        href="/"
                        className="text-blue-600 hover:underline"
                        data-name="login-link"
                    >
                        Go to Login
                    </a>
                </div>
            )}
        </div>
    );
}
