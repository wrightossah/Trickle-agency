function LoginForm({ onSwitchForm }) {
    const [formData, setFormData] = React.useState({
        email: '',
        password: ''
    });
    const [error, setError] = React.useState('');
    const [isLoading, setIsLoading] = React.useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        setIsLoading(true);

        try {
            // First create or get user
            const usersResponse = await trickleListObjects('users', 1, true);
            let userId;

            const existingUser = usersResponse.items.find(user => 
                user.objectData.email === formData.email && 
                user.objectData.password === formData.password
            );

            if (existingUser) {
                userId = existingUser.objectId;
                // Set initial subscription status if not set
                if (existingUser.objectData.isSubscribed === undefined) {
                    await trickleUpdateObject('users', userId, {
                        ...existingUser.objectData,
                        isSubscribed: true,
                        subscriptionEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString() // 30 days trial
                    });
                }
            } else {
                setError('Invalid email or password');
                setIsLoading(false);
                return;
            }

            // Create auth session
            const sessionResponse = await trickleCreateObject('auth-sessions', {
                userId: userId,
                email: formData.email,
                loginTime: new Date().toISOString()
            });

            // Store auth token
            localStorage.setItem('authToken', sessionResponse.objectId);

            // Redirect to dashboard
            window.location.href = '/dashboard';
        } catch (error) {
            reportError(error);
            setError('Login failed. Please try again.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="auth-card" data-name="login-form">
            <div className="auth-header">
                <h1 className="text-2xl font-bold">Welcome Back</h1>
                <p className="text-gray-600">Sign in to your account</p>
            </div>
            {error && (
                <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4" role="alert" data-name="error-message">
                    {error}
                </div>
            )}
            <form onSubmit={handleSubmit} className="auth-form">
                <div>
                    <label className="block text-gray-700 mb-2">Email</label>
                    <input
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({...formData, email: e.target.value})}
                        className="w-full p-2 border rounded"
                        required
                        disabled={isLoading}
                        data-name="email-input"
                    />
                </div>
                <div>
                    <label className="block text-gray-700 mb-2">Password</label>
                    <input
                        type="password"
                        value={formData.password}
                        onChange={(e) => setFormData({...formData, password: e.target.value})}
                        className="w-full p-2 border rounded"
                        required
                        disabled={isLoading}
                        data-name="password-input"
                    />
                </div>
                <button
                    type="submit"
                    className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 disabled:opacity-50"
                    disabled={isLoading}
                    data-name="login-btn"
                >
                    {isLoading ? (
                        <span className="flex items-center justify-center">
                            <i className="fas fa-spinner fa-spin mr-2"></i>
                            Signing in...
                        </span>
                    ) : (
                        'Sign In'
                    )}
                </button>
            </form>
            <div className="auth-links">
                <button
                    onClick={() => onSwitchForm('forgot-password')}
                    className="text-blue-600 hover:underline"
                    disabled={isLoading}
                    data-name="forgot-password-link"
                >
                    Forgot Password?
                </button>
                <p className="mt-2">
                    Don't have an account?{' '}
                    <button
                        onClick={() => onSwitchForm('signup')}
                        className="text-blue-600 hover:underline"
                        disabled={isLoading}
                        data-name="signup-link"
                    >
                        Sign Up
                    </button>
                </p>
            </div>
        </div>
    );
}
