function Header({ title, onMenuClick }) {
    return (
        <div data-name="header-wrapper">
            {/* Mobile Header */}
            <div className="mobile-header" data-name="mobile-header">
                <button
                    onClick={onMenuClick}
                    className="text-gray-600 hover:text-gray-800"
                    data-name="mobile-menu-btn"
                >
                    <i className="fas fa-bars text-xl"></i>
                </button>
                <span className="text-lg font-semibold">{title}</span>
                <button
                    onClick={logout}
                    className="text-gray-600 hover:text-gray-800"
                    data-name="mobile-logout-btn"
                >
                    <i className="fas fa-sign-out-alt"></i>
                </button>
            </div>

            {/* Desktop Header */}
            <header className="bg-white shadow-sm p-4 mb-6 hidden md:flex justify-between items-center" data-name="desktop-header">
                <h1 className="text-2xl font-semibold text-gray-800" data-name="page-title">{title}</h1>
                <button
                    onClick={logout}
                    className="text-gray-600 hover:text-gray-800 flex items-center"
                    data-name="desktop-logout-btn"
                >
                    <i className="fas fa-sign-out-alt mr-2"></i>
                    Logout
                </button>
            </header>
        </div>
    );
}
