function ClientList() {
    const [clients, setClients] = React.useState([]);
    const [selectedClient, setSelectedClient] = React.useState(null);
    const [isViewModalOpen, setIsViewModalOpen] = React.useState(false);
    const [isEditModalOpen, setIsEditModalOpen] = React.useState(false);
    const [isEmailModalOpen, setIsEmailModalOpen] = React.useState(false);
    const [isDeleteModalOpen, setIsDeleteModalOpen] = React.useState(false);
    const [isLoading, setIsLoading] = React.useState(true);
    const [emailData, setEmailData] = React.useState({
        subject: '',
        message: ''
    });

    React.useEffect(() => {
        fetchClients();
    }, []);

    const fetchClients = async () => {
        try {
            setIsLoading(true);
            const response = await trickleListObjects('clients', 1000, true);
            setClients(response.items);
        } catch (error) {
            reportError(error);
            alert('Failed to fetch clients');
        } finally {
            setIsLoading(false);
        }
    };

    const handleDelete = async (clientId) => {
        if (window.confirm('Are you sure you want to delete this client?')) {
            try {
                await trickleDeleteObject('clients', clientId);
                await fetchClients(); // Refresh list
                alert('Client deleted successfully');
            } catch (error) {
                reportError(error);
                alert('Failed to delete client');
            }
        }
    };

    const handleEmailSubmit = async (e) => {
        e.preventDefault();
        try {
            await trickleCreateObject('emails', {
                clientId: selectedClient.objectId,
                subject: emailData.subject,
                message: emailData.message,
                sentAt: new Date().toISOString()
            });
            setIsEmailModalOpen(false);
            setEmailData({ subject: '', message: '' });
            alert('Email sent successfully');
        } catch (error) {
            reportError(error);
            alert('Failed to send email');
        }
    };

    const openWhatsApp = (phoneNumber) => {
        const formattedNumber = phoneNumber.replace(/\D/g, '');
        window.open(`https://wa.me/${formattedNumber}`, '_blank');
    };

    const calculateDaysUntilExpiry = (expiryDate) => {
        const today = new Date();
        const expiry = new Date(expiryDate);
        const diffTime = expiry - today;
        return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    };

    if (isLoading) {
        return (
            <div className="flex justify-center items-center h-64">
                <i className="fas fa-spinner fa-spin text-3xl text-blue-600"></i>
            </div>
        );
    }

    return (
        <div className="container mx-auto px-4" data-name="client-list">
            <div className="overflow-x-auto">
                <table className="min-w-full bg-white shadow-md rounded-lg">
                    <thead className="bg-gray-100">
                        <tr>
                            <th className="px-4 py-3 text-left">Name</th>
                            <th className="px-4 py-3 text-left">Policy Type</th>
                            <th className="px-4 py-3 text-left">Policy Number</th>
                            <th className="px-4 py-3 text-left">Expiry Date</th>
                            <th className="px-4 py-3 text-left">Status</th>
                            <th className="px-4 py-3 text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {clients.map(client => {
                            const daysUntilExpiry = calculateDaysUntilExpiry(client.objectData.expiryDate);
                            const isExpiringSoon = daysUntilExpiry <= 30 && daysUntilExpiry > 0;
                            const isExpired = daysUntilExpiry <= 0;

                            return (
                                <tr key={client.objectId} className="border-b hover:bg-gray-50">
                                    <td className="px-4 py-3">{client.objectData.name}</td>
                                    <td className="px-4 py-3">{client.objectData.policyType}</td>
                                    <td className="px-4 py-3">{client.objectData.policyNumber}</td>
                                    <td className="px-4 py-3">{new Date(client.objectData.expiryDate).toLocaleDateString()}</td>
                                    <td className="px-4 py-3">
                                        {isExpired ? (
                                            <span className="text-red-600">Expired</span>
                                        ) : isExpiringSoon ? (
                                            <span className="text-yellow-600">Expiring Soon</span>
                                        ) : (
                                            <span className="text-green-600">Active</span>
                                        )}
                                    </td>
                                    <td className="px-4 py-3">
                                        <div className="flex justify-center space-x-2">
                                            <button
                                                onClick={() => {
                                                    setSelectedClient(client);
                                                    setIsViewModalOpen(true);
                                                }}
                                                className="text-blue-600 hover:text-blue-800"
                                                title="View Details"
                                                data-name="view-btn"
                                            >
                                                <i className="fas fa-eye"></i>
                                            </button>
                                            <button
                                                onClick={() => {
                                                    setSelectedClient(client);
                                                    setIsEditModalOpen(true);
                                                }}
                                                className="text-green-600 hover:text-green-800"
                                                title="Edit"
                                                data-name="edit-btn"
                                            >
                                                <i className="fas fa-edit"></i>
                                            </button>
                                            <button
                                                onClick={() => handleDelete(client.objectId)}
                                                className="text-red-600 hover:text-red-800"
                                                title="Delete"
                                                data-name="delete-btn"
                                            >
                                                <i className="fas fa-trash"></i>
                                            </button>
                                            <button
                                                onClick={() => {
                                                    setSelectedClient(client);
                                                    setIsEmailModalOpen(true);
                                                }}
                                                className="text-purple-600 hover:text-purple-800"
                                                title="Send Email"
                                                data-name="email-btn"
                                            >
                                                <i className="fas fa-envelope"></i>
                                            </button>
                                            <button
                                                onClick={() => openWhatsApp(client.objectData.phone)}
                                                className="text-green-600 hover:text-green-800"
                                                title="Send WhatsApp"
                                                data-name="whatsapp-btn"
                                            >
                                                <i className="fab fa-whatsapp"></i>
                                            </button>
                                            {isExpiringSoon && (
                                                <span className="text-yellow-600" title={`Expires in ${daysUntilExpiry} days`}>
                                                    <i className="fas fa-bell"></i>
                                                </span>
                                            )}
                                        </div>
                                    </td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
            </div>

            {/* View Modal */}
            {isViewModalOpen && selectedClient && (
                <ViewClientModal
                    client={selectedClient}
                    onClose={() => setIsViewModalOpen(false)}
                />
            )}

            {/* Edit Modal */}
            {isEditModalOpen && selectedClient && (
                <AddClientModal
                    isOpen={true}
                    onClose={() => setIsEditModalOpen(false)}
                    onSuccess={() => {
                        setIsEditModalOpen(false);
                        fetchClients();
                    }}
                    initialData={selectedClient.objectData}
                    clientId={selectedClient.objectId}
                />
            )}

            {/* Email Modal */}
            {isEmailModalOpen && selectedClient && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" data-name="email-modal">
                    <div className="bg-white rounded-lg p-6 w-full max-w-lg">
                        <div className="flex justify-between items-center mb-4">
                            <h2 className="text-xl font-bold">Send Email</h2>
                            <button
                                onClick={() => setIsEmailModalOpen(false)}
                                className="text-gray-500 hover:text-gray-700"
                            >
                                <i className="fas fa-times"></i>
                            </button>
                        </div>
                        <form onSubmit={handleEmailSubmit} className="space-y-4">
                            <div>
                                <label className="block text-gray-700 mb-2">To:</label>
                                <input
                                    type="text"
                                    value={selectedClient.objectData.email}
                                    disabled
                                    className="w-full p-2 border rounded bg-gray-100"
                                />
                            </div>
                            <div>
                                <label className="block text-gray-700 mb-2">Subject:</label>
                                <input
                                    type="text"
                                    value={emailData.subject}
                                    onChange={(e) => setEmailData({ ...emailData, subject: e.target.value })}
                                    className="w-full p-2 border rounded"
                                    required
                                />
                            </div>
                            <div>
                                <label className="block text-gray-700 mb-2">Message:</label>
                                <textarea
                                    value={emailData.message}
                                    onChange={(e) => setEmailData({ ...emailData, message: e.target.value })}
                                    className="w-full p-2 border rounded h-32"
                                    required
                                ></textarea>
                            </div>
                            <div className="flex justify-end gap-4">
                                <button
                                    type="button"
                                    onClick={() => setIsEmailModalOpen(false)}
                                    className="px-4 py-2 text-gray-600 hover:text-gray-800"
                                >
                                    Cancel
                                </button>
                                <button
                                    type="submit"
                                    className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
                                >
                                    Send Email
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
}
