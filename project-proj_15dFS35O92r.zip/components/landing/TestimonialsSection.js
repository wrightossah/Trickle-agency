function TestimonialsSection() {
    const testimonials = [
        {
            name: "Sarah Johnson",
            role: "Insurance Agent",
            content: "This CRM has transformed how I manage my clients. The automated reminders save me hours every week."
        },
        {
            name: "Michael Chen",
            role: "Agency Owner",
            content: "The analytics and reporting features help me make data-driven decisions for my business."
        },
        {
            name: "Emily Rodriguez",
            role: "Insurance Broker",
            content: "Easy to use and incredibly effective. My client retention has improved significantly."
        }
    ];

    return (
        <section className="py-20 bg-gray-100" data-name="testimonials-section">
            <div className="container mx-auto px-4">
                <h2 className="text-4xl font-bold text-center mb-12">What Our Users Say</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {testimonials.map((testimonial, index) => (
                        <div
                            key={index}
                            className="testimonial-card"
                            data-name={`testimonial-${index}`}
                        >
                            <p className="text-gray-600 mb-4">"{testimonial.content}"</p>
                            <div className="flex items-center">
                                <div className="ml-3">
                                    <h4 className="font-semibold">{testimonial.name}</h4>
                                    <p className="text-gray-500">{testimonial.role}</p>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
}
