function HeroSection() {
    const [isScrolled, setIsScrolled] = React.useState(false);

    React.useEffect(() => {
        const handleScroll = () => {
            setIsScrolled(window.scrollY > 50);
        };
        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    return (
        <div data-name="hero-section">
            <nav className={`navbar ${isScrolled ? 'scrolled' : ''}`} data-name="navbar">
                <div className="container mx-auto flex justify-between items-center">
                    <div className="text-2xl font-bold" data-name="logo">WRIGHT AGENCYAPP</div>
                    <div className="space-x-4">
                        <a href="#features" className="text-white hover:text-blue-400" data-name="features-link">Features</a>
                        <a href="#pricing" className="text-white hover:text-blue-400" data-name="pricing-link">Pricing</a>
                        <button
                            onClick={() => window.location.href = '/login'}
                            className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
                            data-name="login-btn"
                        >
                            Login
                        </button>
                    </div>
                </div>
            </nav>
            <div className="hero-section flex items-center justify-center text-center">
                <div className="container mx-auto px-4">
                    <h1 className="text-5xl md:text-6xl font-bold mb-6" data-name="hero-title">
                        Streamline Your Insurance Agency
                    </h1>
                    <p className="text-xl md:text-2xl mb-8 max-w-2xl mx-auto" data-name="hero-subtitle">
                        Manage clients, track policies, and grow your business with our comprehensive CRM solution
                    </p>
                    <button
                        onClick={() => window.location.href = '/signup'}
                        className="bg-blue-600 text-white text-lg px-8 py-4 rounded-lg hover:bg-blue-700 transform hover:scale-105 transition-all"
                        data-name="get-started-btn"
                    >
                        Get Started Now
                    </button>
                </div>
            </div>
        </div>
    );
}
