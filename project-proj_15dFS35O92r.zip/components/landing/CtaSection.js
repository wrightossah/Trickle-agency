function CtaSection() {
    return (
        <section className="cta-section py-20" data-name="cta-section">
            <div className="container mx-auto px-4 text-center">
                <h2 className="text-4xl font-bold mb-6">Ready to Grow Your Insurance Business?</h2>
                <p className="text-xl mb-8 max-w-2xl mx-auto">
                    Join thousands of insurance agents who are already using our CRM to streamline their operations
                </p>
                <button
                    onClick={() => window.location.href = '/signup'}
                    className="bg-blue-600 text-white text-lg px-8 py-4 rounded-lg hover:bg-blue-700"
                    data-name="cta-btn"
                >
                    Get Started Free
                </button>
            </div>
        </section>
    );
}
