function PricingSection() {
    return (
        <section id="pricing" className="py-20" data-name="pricing-section">
            <div className="container mx-auto px-4">
                <h2 className="text-4xl font-bold text-center mb-12">Simple, Transparent Pricing</h2>
                <div className="max-w-4xl mx-auto">
                    <div className="pricing-card text-center">
                        <h3 className="text-2xl font-bold mb-4">Monthly Subscription</h3>
                        <div className="text-4xl font-bold mb-4">
                            GHC 20<span className="text-xl text-gray-600">/month</span>
                        </div>
                        <ul className="text-gray-600 mb-8 space-y-3">
                            <li>Unlimited Client Management</li>
                            <li>Policy Tracking & Reminders</li>
                            <li>Sales Analytics & Reports</li>
                            <li>Email & SMS Notifications</li>
                            <li>24/7 Customer Support</li>
                        </ul>
                        <div className="text-green-600 mb-8">
                            <div>Special Offers:</div>
                            <div>12 months - Get 2 months free</div>
                            <div>24 months - Get 4 months free</div>
                        </div>
                        <button
                            onClick={() => window.location.href = '/signup'}
                            className="bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 w-full"
                            data-name="start-trial-btn"
                        >
                            Start Free Trial
                        </button>
                    </div>
                </div>
            </div>
        </section>
    );
}
