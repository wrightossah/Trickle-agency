function FeaturesSection() {
    const features = [
        {
            icon: 'fas fa-users',
            title: 'Client Management',
            description: 'Efficiently manage your client database with detailed profiles and contact information'
        },
        {
            icon: 'fas fa-file-contract',
            title: 'Policy Tracking',
            description: 'Track policy expiration dates and receive automated reminders for renewals'
        },
        {
            icon: 'fas fa-chart-line',
            title: 'Sales Analytics',
            description: 'Monitor your performance with intuitive charts and comprehensive reports'
        },
        {
            icon: 'fas fa-bell',
            title: 'Automated Reminders',
            description: 'Send automated email and SMS reminders to clients for policy renewals'
        }
    ];

    return (
        <section id="features" className="py-20 bg-gray-50" data-name="features-section">
            <div className="container mx-auto px-4">
                <h2 className="text-4xl font-bold text-center mb-12">Powerful Features</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                    {features.map((feature, index) => (
                        <div
                            key={index}
                            className="feature-card bg-white p-6 rounded-lg shadow-md text-center"
                            data-name={`feature-card-${index}`}
                        >
                            <i className={`${feature.icon} text-4xl text-blue-600 mb-4`}></i>
                            <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
                            <p className="text-gray-600">{feature.description}</p>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
}
