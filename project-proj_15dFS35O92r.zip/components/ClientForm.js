function ClientForm() {
    const [formData, setFormData] = React.useState({
        name: '',
        email: '',
        phone: '',
        policyNumber: '',
        expiryDate: ''
    });

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await trickleCreateObject('clients', formData);
            setFormData({
                name: '',
                email: '',
                phone: '',
                policyNumber: '',
                expiryDate: ''
            });
        } catch (error) {
            reportError(error);
        }
    };

    return (
        <form onSubmit={handleSubmit} className="card" data-name="client-form">
            <h2 className="text-xl font-semibold mb-4">Add New Client</h2>
            <div className="form-group">
                <label className="block text-gray-700 mb-2">Name</label>
                <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    className="w-full p-2 border rounded"
                    required
                    data-name="name-input"
                />
            </div>
            <div className="form-group">
                <label className="block text-gray-700 mb-2">Email</label>
                <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                    className="w-full p-2 border rounded"
                    required
                    data-name="email-input"
                />
            </div>
            <div className="form-group">
                <label className="block text-gray-700 mb-2">Phone</label>
                <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({...formData, phone: e.target.value})}
                    className="w-full p-2 border rounded"
                    required
                    data-name="phone-input"
                />
            </div>
            <div className="form-group">
                <label className="block text-gray-700 mb-2">Policy Number</label>
                <input
                    type="text"
                    value={formData.policyNumber}
                    onChange={(e) => setFormData({...formData, policyNumber: e.target.value})}
                    className="w-full p-2 border rounded"
                    required
                    data-name="policy-input"
                />
            </div>
            <div className="form-group">
                <label className="block text-gray-700 mb-2">Policy Expiry Date</label>
                <input
                    type="date"
                    value={formData.expiryDate}
                    onChange={(e) => setFormData({...formData, expiryDate: e.target.value})}
                    className="w-full p-2 border rounded"
                    required
                    data-name="expiry-input"
                />
            </div>
            <button
                type="submit"
                className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
                data-name="submit-btn"
            >
                Add Client
            </button>
        </form>
    );
}
