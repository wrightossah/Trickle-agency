function SubscriptionForm() {
    const [months, setMonths] = React.useState(1);
    const [isProcessing, setIsProcessing] = React.useState(false);
    const [error, setError] = React.useState('');
    const [userEmail, setUserEmail] = React.useState('');
    const monthlyRate = 20; // GHC 20 per month

    React.useEffect(() => {
        const fetchUserEmail = async () => {
            try {
                const user = await getCurrentUser();
                if (user && user.objectData.email) {
                    setUserEmail(user.objectData.email);
                }
            } catch (error) {
                reportError(error);
            }
        };
        fetchUserEmail();
    }, []);

    const calculatePrice = () => {
        let totalMonths = months;
        let freeMonths = 0;

        if (months >= 12) {
            freeMonths = Math.floor(months / 6); // 2 free months per year
        }

        const effectiveMonths = totalMonths - freeMonths;
        return effectiveMonths * monthlyRate;
    };

    const handlePaystackSuccessAction = async (reference) => {
        try {
            const user = await getCurrentUser();
            if (!user) {
                throw new Error('User not found');
            }

            // Create subscription record
            await trickleCreateObject('subscriptions', {
                userId: user.objectId,
                months: months,
                amount: calculatePrice(),
                reference: reference,
                startDate: new Date().toISOString(),
                endDate: getSubscriptionEndDate(months)
            });

            // Update user subscription status
            await updateUserSubscription(user.objectId, {
                isSubscribed: true,
                subscriptionEnd: getSubscriptionEndDate(months)
            });

            // Redirect to dashboard
            window.location.href = '/dashboard';
        } catch (error) {
            reportError(error);
            setError('Failed to update subscription. Please contact support.');
        }
    };

    const handlePayment = async (e) => {
        e.preventDefault();
        setError('');
        setIsProcessing(true);

        try {
            if (!userEmail) {
                throw new Error('User email not found');
            }

            const amount = calculatePrice();
            const handler = window.PaystackPop.setup({
                key: 'pk_test_b6a8830d043f2d7420be7f9275209ca34535cf83',
                email: userEmail,
                amount: amount * 100, // Convert to pesewas
                currency: 'GHS',
                ref: 'sub_' + Math.floor((Math.random() * 1000000000) + 1),
                callback: async function(response) {
                    if (response.status === 'success') {
                        await handlePaystackSuccessAction(response.reference);
                    } else {
                        setError('Payment failed. Please try again.');
                    }
                },
                onClose: function() {
                    setIsProcessing(false);
                }
            });
            handler.openIframe();
        } catch (error) {
            reportError(error);
            setError(error.message || 'Payment failed. Please try again.');
            setIsProcessing(false);
        }
    };

    return (
        <div className="subscription-container" data-name="subscription-form">
            <div className="subscription-header">
                <h1 className="text-2xl font-bold mb-2">Choose Your Subscription Plan</h1>
                <p className="text-gray-600">Select the number of months for your subscription</p>
            </div>

            {error && (
                <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4" role="alert" data-name="error-message">
                    {error}
                </div>
            )}

            <form onSubmit={handlePayment} className="subscription-form">
                <div>
                    <label className="block text-gray-700 mb-2">Number of Months</label>
                    <input
                        type="range"
                        min="1"
                        max="24"
                        value={months}
                        onChange={(e) => setMonths(parseInt(e.target.value))}
                        className="months-slider"
                        data-name="months-slider"
                    />
                    <div className="text-center mt-2">
                        <span className="text-lg font-semibold">{months} months</span>
                    </div>
                </div>

                <div className="price-display">
                    <div className="text-xl">Total Price</div>
                    <div className="text-3xl font-bold">GHC {calculatePrice()}</div>
                    {months >= 12 && (
                        <div className="discount-badge">
                            {Math.floor(months / 6)} months free!
                        </div>
                    )}
                </div>

                <div className="text-sm text-gray-600 text-center mb-4">
                    <i className="fas fa-lock mr-1"></i>
                    Secure payment powered by Paystack
                </div>

                <button
                    type="submit"
                    className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 disabled:opacity-50 flex items-center justify-center"
                    disabled={isProcessing}
                    data-name="subscribe-btn"
                >
                    {isProcessing ? (
                        <span className="flex items-center">
                            <i className="fas fa-spinner fa-spin mr-2"></i>
                            Processing...
                        </span>
                    ) : (
                        <span className="flex items-center">
                            <i className="fas fa-credit-card mr-2"></i>
                            Pay GHC {calculatePrice()}
                        </span>
                    )}
                </button>
            </form>

            <div className="mt-6 text-center text-sm text-gray-600">
                <p>By subscribing, you agree to our terms of service and privacy policy.</p>
            </div>
        </div>
    );
}
