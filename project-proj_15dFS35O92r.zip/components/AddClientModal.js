function AddClientModal({ isOpen, onClose, onSuccess }) {
    const [formData, setFormData] = React.useState({
        name: '',
        address: '',
        phone: '',
        email: '',
        policyType: '',
        policyNumber: '',
        inceptionDate: '',
        expiryDate: '',
        premiumAmount: '',
        // Auto/Motor specific fields
        vehicleNumber: '',
        vehicleMake: '',
        vehicleType: '',
        chassisNumber: '',
        vehicleColor: '',
        ccHP: '',
        vehicleValue: '',
        vehicleCurrency: 'GHC'
    });

    const [errors, setErrors] = React.useState({});
    const [isSubmitting, setIsSubmitting] = React.useState(false);

    const policyTypes = [
        "Auto/Motor",
        "Travel",
        "Goods in Transit",
        "Marine",
        "Funeral",
        "Education",
        "Whole Term",
        "Contractors All Risk",
        "Performance Bonds",
        "Fire and Burglary",
        "Personal Accident"
    ];

    const validateForm = () => {
        const newErrors = {};
        
        // Basic fields validation
        if (!formData.name.trim()) {
            newErrors.name = 'Name is required';
        }

        if (!formData.phone.trim()) {
            newErrors.phone = 'Phone number is required';
        } else if (!/^\+?[\d\s-]{10,}$/.test(formData.phone.trim())) {
            newErrors.phone = 'Invalid phone number';
        }

        if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
            newErrors.email = 'Invalid email format';
        }

        if (!formData.policyType) {
            newErrors.policyType = 'Policy type is required';
        }

        if (!formData.policyNumber) {
            newErrors.policyNumber = 'Policy number is required';
        }

        if (!formData.inceptionDate) {
            newErrors.inceptionDate = 'Inception date is required';
        }

        if (!formData.expiryDate) {
            newErrors.expiryDate = 'Expiry date is required';
        } else if (new Date(formData.expiryDate) <= new Date(formData.inceptionDate)) {
            newErrors.expiryDate = 'Expiry date must be after inception date';
        }

        if (!formData.premiumAmount) {
            newErrors.premiumAmount = 'Premium amount is required';
        } else if (isNaN(formData.premiumAmount) || parseFloat(formData.premiumAmount) <= 0) {
            newErrors.premiumAmount = 'Invalid premium amount';
        }

        // Auto/Motor specific validation
        if (formData.policyType === 'Auto/Motor') {
            if (!formData.vehicleNumber) {
                newErrors.vehicleNumber = 'Vehicle number is required';
            }
            if (!formData.vehicleMake) {
                newErrors.vehicleMake = 'Make of vehicle is required';
            }
            if (!formData.vehicleType) {
                newErrors.vehicleType = 'Type of vehicle is required';
            }
            if (!formData.chassisNumber) {
                newErrors.chassisNumber = 'Chassis number is required';
            }
            if (!formData.vehicleColor) {
                newErrors.vehicleColor = 'Vehicle color is required';
            }
            if (!formData.ccHP) {
                newErrors.ccHP = 'CC/HP is required';
            }
            if (!formData.vehicleValue) {
                newErrors.vehicleValue = 'Vehicle value is required';
            }
        }

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        if (!validateForm()) {
            return;
        }

        setIsSubmitting(true);

        try {
            const response = await trickleCreateObject('clients', formData);
            
            if (response) {
                onSuccess();
                onClose();
                // Show success notification
                const successNotification = document.createElement('div');
                successNotification.className = 'fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded shadow-lg z-50';
                successNotification.textContent = 'Client added successfully!';
                document.body.appendChild(successNotification);
                setTimeout(() => {
                    successNotification.remove();
                }, 3000);
            }
        } catch (error) {
            reportError(error);
            setErrors({ submit: 'Failed to add client. Please try again.' });
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
        // Clear error when user starts typing
        if (errors[name]) {
            setErrors(prev => ({
                ...prev,
                [name]: ''
            }));
        }
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" data-name="add-client-modal">
            <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
                <div className="flex justify-between items-center mb-6">
                    <h2 className="text-2xl font-bold">Add New Client</h2>
                    <button
                        onClick={onClose}
                        className="text-gray-500 hover:text-gray-700"
                        data-name="close-modal"
                    >
                        <i className="fas fa-times"></i>
                    </button>
                </div>

                {errors.submit && (
                    <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4" data-name="error-message">
                        {errors.submit}
                    </div>
                )}

                <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {/* Basic Client Information */}
                        <div>
                            <label className="block text-gray-700 mb-2">Name *</label>
                            <input
                                type="text"
                                name="name"
                                value={formData.name}
                                onChange={handleChange}
                                className={`w-full p-2 border rounded ${errors.name ? 'border-red-500' : 'border-gray-300'}`}
                                data-name="name-input"
                            />
                            {errors.name && <p className="text-red-500 text-sm mt-1">{errors.name}</p>}
                        </div>

                        <div>
                            <label className="block text-gray-700 mb-2">Phone *</label>
                            <input
                                type="tel"
                                name="phone"
                                value={formData.phone}
                                onChange={handleChange}
                                className={`w-full p-2 border rounded ${errors.phone ? 'border-red-500' : 'border-gray-300'}`}
                                data-name="phone-input"
                            />
                            {errors.phone && <p className="text-red-500 text-sm mt-1">{errors.phone}</p>}
                        </div>

                        <div>
                            <label className="block text-gray-700 mb-2">Email</label>
                            <input
                                type="email"
                                name="email"
                                value={formData.email}
                                onChange={handleChange}
                                className={`w-full p-2 border rounded ${errors.email ? 'border-red-500' : 'border-gray-300'}`}
                                data-name="email-input"
                            />
                            {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email}</p>}
                        </div>

                        <div>
                            <label className="block text-gray-700 mb-2">Address</label>
                            <input
                                type="text"
                                name="address"
                                value={formData.address}
                                onChange={handleChange}
                                className="w-full p-2 border rounded border-gray-300"
                                data-name="address-input"
                            />
                        </div>

                        {/* Policy Information */}
                        <div>
                            <label className="block text-gray-700 mb-2">Policy Type *</label>
                            <select
                                name="policyType"
                                value={formData.policyType}
                                onChange={handleChange}
                                className={`w-full p-2 border rounded ${errors.policyType ? 'border-red-500' : 'border-gray-300'}`}
                                data-name="policy-type-input"
                            >
                                <option value="">Select Policy Type</option>
                                {policyTypes.map(type => (
                                    <option key={type} value={type}>{type}</option>
                                ))}
                            </select>
                            {errors.policyType && <p className="text-red-500 text-sm mt-1">{errors.policyType}</p>}
                        </div>

                        <div>
                            <label className="block text-gray-700 mb-2">Policy Number *</label>
                            <input
                                type="text"
                                name="policyNumber"
                                value={formData.policyNumber}
                                onChange={handleChange}
                                className={`w-full p-2 border rounded ${errors.policyNumber ? 'border-red-500' : 'border-gray-300'}`}
                                data-name="policy-number-input"
                            />
                            {errors.policyNumber && <p className="text-red-500 text-sm mt-1">{errors.policyNumber}</p>}
                        </div>

                        <div>
                            <label className="block text-gray-700 mb-2">Inception Date *</label>
                            <input
                                type="date"
                                name="inceptionDate"
                                value={formData.inceptionDate}
                                onChange={handleChange}
                                className={`w-full p-2 border rounded ${errors.inceptionDate ? 'border-red-500' : 'border-gray-300'}`}
                                data-name="inception-date-input"
                            />
                            {errors.inceptionDate && <p className="text-red-500 text-sm mt-1">{errors.inceptionDate}</p>}
                        </div>

                        <div>
                            <label className="block text-gray-700 mb-2">Expiry Date *</label>
                            <input
                                type="date"
                                name="expiryDate"
                                value={formData.expiryDate}
                                onChange={handleChange}
                                className={`w-full p-2 border rounded ${errors.expiryDate ? 'border-red-500' : 'border-gray-300'}`}
                                data-name="expiry-date-input"
                            />
                            {errors.expiryDate && <p className="text-red-500 text-sm mt-1">{errors.expiryDate}</p>}
                        </div>

                        <div>
                            <label className="block text-gray-700 mb-2">Premium Amount *</label>
                            <input
                                type="number"
                                name="premiumAmount"
                                value={formData.premiumAmount}
                                onChange={handleChange}
                                min="0"
                                step="0.01"
                                className={`w-full p-2 border rounded ${errors.premiumAmount ? 'border-red-500' : 'border-gray-300'}`}
                                data-name="premium-amount-input"
                            />
                            {errors.premiumAmount && <p className="text-red-500 text-sm mt-1">{errors.premiumAmount}</p>}
                        </div>

                        {/* Auto/Motor Specific Fields */}
                        {formData.policyType === 'Auto/Motor' && (
                            <React.Fragment>
                                <div>
                                    <label className="block text-gray-700 mb-2">Vehicle Number *</label>
                                    <input
                                        type="text"
                                        name="vehicleNumber"
                                        value={formData.vehicleNumber}
                                        onChange={handleChange}
                                        className={`w-full p-2 border rounded ${errors.vehicleNumber ? 'border-red-500' : 'border-gray-300'}`}
                                        data-name="vehicle-number-input"
                                    />
                                    {errors.vehicleNumber && <p className="text-red-500 text-sm mt-1">{errors.vehicleNumber}</p>}
                                </div>

                                <div>
                                    <label className="block text-gray-700 mb-2">Make of Vehicle *</label>
                                    <input
                                        type="text"
                                        name="vehicleMake"
                                        value={formData.vehicleMake}
                                        onChange={handleChange}
                                        className={`w-full p-2 border rounded ${errors.vehicleMake ? 'border-red-500' : 'border-gray-300'}`}
                                        data-name="vehicle-make-input"
                                    />
                                    {errors.vehicleMake && <p className="text-red-500 text-sm mt-1">{errors.vehicleMake}</p>}
                                </div>

                                <div>
                                    <label className="block text-gray-700 mb-2">Type of Vehicle *</label>
                                    <input
                                        type="text"
                                        name="vehicleType"
                                        value={formData.vehicleType}
                                        onChange={handleChange}
                                        className={`w-full p-2 border rounded ${errors.vehicleType ? 'border-red-500' : 'border-gray-300'}`}
                                        data-name="vehicle-type-input"
                                    />
                                    {errors.vehicleType && <p className="text-red-500 text-sm mt-1">{errors.vehicleType}</p>}
                                </div>

                                <div>
                                    <label className="block text-gray-700 mb-2">Chassis Number *</label>
                                    <input
                                        type="text"
                                        name="chassisNumber"
                                        value={formData.chassisNumber}
                                        onChange={handleChange}
                                        className={`w-full p-2 border rounded ${errors.chassisNumber ? 'border-red-500' : 'border-gray-300'}`}
                                        data-name="chassis-number-input"
                                    />
                                    {errors.chassisNumber && <p className="text-red-500 text-sm mt-1">{errors.chassisNumber}</p>}
                                </div>

                                <div>
                                    <label className="block text-gray-700 mb-2">Vehicle Color *</label>
                                    <input
                                        type="text"
                                        name="vehicleColor"
                                        value={formData.vehicleColor}
                                        onChange={handleChange}
                                        className={`w-full p-2 border rounded ${errors.vehicleColor ? 'border-red-500' : 'border-gray-300'}`}
                                        data-name="vehicle-color-input"
                                    />
                                    {errors.vehicleColor && <p className="text-red-500 text-sm mt-1">{errors.vehicleColor}</p>}
                                </div>

                                <div>
                                    <label className="block text-gray-700 mb-2">CC/HP *</label>
                                    <input
                                        type="text"
                                        name="ccHP"
                                        value={formData.ccHP}
                                        onChange={handleChange}
                                        className={`w-full p-2 border rounded ${errors.ccHP ? 'border-red-500' : 'border-gray-300'}`}
                                        data-name="cc-hp-input"
                                    />
                                    {errors.ccHP && <p className="text-red-500 text-sm mt-1">{errors.ccHP}</p>}
                                </div>

                                <div>
                                    <label className="block text-gray-700 mb-2">Vehicle Value *</label>
                                    <div className="flex gap-2">
                                        <select
                                            name="vehicleCurrency"
                                            value={formData.vehicleCurrency}
                                            onChange={handleChange}
                                            className="w-24 p-2 border rounded border-gray-300"
                                            data-name="vehicle-currency-input"
                                        >
                                            <option value="GHC">GHC</option>
                                            <option value="USD">USD</option>
                                        </select>
                                        <input
                                            type="number"
                                            name="vehicleValue"
                                            value={formData.vehicleValue}
                                            onChange={handleChange}
                                            className={`flex-1 p-2 border rounded ${errors.vehicleValue ? 'border-red-500' : 'border-gray-300'}`}
                                            data-name="vehicle-value-input"
                                        />
                                    </div>
                                    {errors.vehicleValue && <p className="text-red-500 text-sm mt-1">{errors.vehicleValue}</p>}
                                </div>
                            </React.Fragment>
                        )}
                    </div>

                    <div className="flex justify-end gap-4 mt-6">
                        <button
                            type="button"
                            onClick={onClose}
                            className="px-4 py-2 text-gray-600 hover:text-gray-800"
                            data-name="cancel-btn"
                        >
                            Cancel
                        </button>
                        <button
                            type="submit"
                            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50 flex items-center"
                            disabled={isSubmitting}
                            data-name="submit-btn"
                        >
                            {isSubmitting ? (
                                <span className="flex items-center">
                                    <i className="fas fa-spinner fa-spin mr-2"></i>
                                    Saving...
                                </span>
                            ) : (
                                'Save Client'
                            )}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
}
