function ReportDialog({ isOpen, onClose }) {
    const [clients, setClients] = React.useState([]);
    const [selectedClients, setSelectedClients] = React.useState([]);
    const [isLoading, setIsLoading] = React.useState(true);

    React.useEffect(() => {
        if (isOpen) {
            fetchClients();
        }
    }, [isOpen]);

    const fetchClients = async () => {
        try {
            const response = await trickleListObjects('clients', 1000, true);
            setClients(response.items);
            setIsLoading(false);
        } catch (error) {
            reportError(error);
            setIsLoading(false);
        }
    };

    const handleCheckboxChange = (clientId) => {
        setSelectedClients(prev => 
            prev.includes(clientId)
                ? prev.filter(id => id !== clientId)
                : [...prev, clientId]
        );
    };

    const handleGenerateReport = () => {
        try {
            const selectedClientData = clients.filter(client => 
                selectedClients.includes(client.objectId)
            );
            generatePDFReport(selectedClientData);
            onClose();
        } catch (error) {
            reportError(error);
        }
    };

    if (!isOpen) return null;

    return (
        <div className="dialog-overlay" data-name="report-dialog">
            <div className="dialog-content">
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-xl font-semibold">Generate Client Report</h2>
                    <button
                        onClick={onClose}
                        className="text-gray-500 hover:text-gray-700"
                        data-name="close-dialog"
                    >
                        <i className="fas fa-times"></i>
                    </button>
                </div>
                {isLoading ? (
                    <div className="text-center py-4">Loading clients...</div>
                ) : (
                    <div>
                        <table className="report-table">
                            <thead>
                                <tr>
                                    <th>Select</th>
                                    <th>Name</th>
                                    <th>Phone</th>
                                    <th>Policy Number</th>
                                    <th>Expiry Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                {clients.map(client => (
                                    <tr key={client.objectId}>
                                        <td>
                                            <input
                                                type="checkbox"
                                                checked={selectedClients.includes(client.objectId)}
                                                onChange={() => handleCheckboxChange(client.objectId)}
                                                data-name="client-checkbox"
                                            />
                                        </td>
                                        <td>{client.objectData.name}</td>
                                        <td>{client.objectData.phone}</td>
                                        <td>{client.objectData.policyNumber}</td>
                                        <td>{formatDate(client.objectData.expiryDate)}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                        <div className="mt-4 flex justify-end gap-2">
                            <button
                                onClick={onClose}
                                className="px-4 py-2 text-gray-600 hover:text-gray-800"
                                data-name="cancel-btn"
                            >
                                Cancel
                            </button>
                            <button
                                onClick={handleGenerateReport}
                                className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
                                disabled={selectedClients.length === 0}
                                data-name="generate-btn"
                            >
                                Generate Report
                            </button>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}
