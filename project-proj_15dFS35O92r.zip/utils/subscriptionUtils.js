function getSubscriptionEndDate(months) {
    try {
        const date = new Date();
        date.setMonth(date.getMonth() + months);
        return date.toISOString();
    } catch (error) {
        reportError(error);
        return null;
    }
}

async function getCurrentUser() {
    try {
        const token = localStorage.getItem('authToken');
        if (!token) {
            throw new Error('No auth token found');
        }
        
        const session = await trickleGetObject('auth-sessions', token);
        if (!session || !session.objectData || !session.objectData.userId) {
            throw new Error('Invalid session data');
        }
        
        return await trickleGetObject('users', session.objectData.userId);
    } catch (error) {
        reportError(error);
        throw error;
    }
}

async function updateUserSubscription(userId, subscriptionData) {
    try {
        await trickleUpdateObject('users', userId, subscriptionData);
    } catch (error) {
        reportError(error);
        throw error;
    }
}

async function checkSubscriptionStatus() {
    try {
        const token = localStorage.getItem('authToken');
        if (!token) return false;

        const user = await getCurrentUser();
        if (!user || !user.objectData || !user.objectData.isSubscribed) {
            return false;
        }
        
        const subscriptionEnd = new Date(user.objectData.subscriptionEnd);
        return subscriptionEnd > new Date();
    } catch (error) {
        reportError(error);
        return false;
    }
}
