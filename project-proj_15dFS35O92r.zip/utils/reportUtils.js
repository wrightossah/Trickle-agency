function generatePDFReport(clients) {
    try {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        
        // Add title
        doc.setFontSize(20);
        doc.text('Client Policy Report', 20, 20);
        
        // Add current date
        doc.setFontSize(12);
        doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 20, 30);
        
        // Add table headers
        const headers = ['Name', 'Phone', 'Policy Number', 'Expiry Date'];
        let yPos = 40;
        const xPositions = [20, 70, 120, 170];
        
        doc.setFont(undefined, 'bold');
        headers.forEach((header, index) => {
            doc.text(header, xPositions[index], yPos);
        });
        
        // Add table content
        doc.setFont(undefined, 'normal');
        clients.forEach((client, index) => {
            yPos += 10;
            
            // Add new page if needed
            if (yPos > 280) {
                doc.addPage();
                yPos = 20;
            }
            
            const row = [
                client.objectData.name,
                client.objectData.phone,
                client.objectData.policyNumber,
                formatDate(client.objectData.expiryDate)
            ];
            
            row.forEach((text, colIndex) => {
                doc.text(text.toString(), xPositions[colIndex], yPos);
            });
        });
        
        // Save the PDF
        doc.save('client-policy-report.pdf');
    } catch (error) {
        reportError(error);
    }
}
