const dummyClients = [
    {
        name: "John Doe",
        address: "123 Main Street, Accra",
        phone: "+233 24 123 4567",
        email: "john.doe@email.com",
        policyType: "Auto/Motor",
        policyNumber: "AM-2024-001",
        inceptionDate: "2024-01-01",
        expiryDate: "2024-12-31",
        premiumAmount: "2500",
        vehicleNumber: "GR-123-24",
        vehicleMake: "Toyota",
        vehicleType: "Camry",
        chassisNumber: "TOY123CAM456",
        vehicleColor: "Silver",
        ccHP: "2400",
        vehicleValue: "85000",
        vehicleCurrency: "GHC"
    },
    {
        name: "Sarah Johnson",
        address: "45 Independence Ave, Kumasi",
        phone: "+233 25 987 6543",
        email: "sarah.j@email.com",
        policyType: "Fire and Burglary",
        policyNumber: "FB-2024-002",
        inceptionDate: "2024-02-15",
        expiryDate: "2025-02-14",
        premiumAmount: "1800"
    },
    {
        name: "Kwame Mensah",
        address: "78 High Street, Tema",
        phone: "+233 20 555 7890",
        email: "kwame.m@email.com",
        policyType: "Auto/Motor",
        policyNumber: "AM-2024-003",
        inceptionDate: "2024-03-01",
        expiryDate: "2024-06-30",
        premiumAmount: "3200",
        vehicleNumber: "GT-456-24",
        vehicleMake: "Honda",
        vehicleType: "CR-V",
        chassisNumber: "HON456CRV789",
        vehicleColor: "Black",
        ccHP: "2000",
        vehicleValue: "95000",
        vehicleCurrency: "GHC"
    },
    {
        name: "Aisha Bello",
        address: "234 Beach Road, Cape Coast",
        phone: "+233 27 444 1111",
        email: "aisha.b@email.com",
        policyType: "Personal Accident",
        policyNumber: "PA-2024-004",
        inceptionDate: "2024-01-15",
        expiryDate: "2025-01-14",
        premiumAmount: "1500"
    },
    {
        name: "Emmanuel Koffi",
        address: "567 Market Street, Takoradi",
        phone: "+233 23 222 3333",
        email: "emmanuel.k@email.com",
        policyType: "Marine",
        policyNumber: "MA-2024-005",
        inceptionDate: "2024-02-01",
        expiryDate: "2024-07-31",
        premiumAmount: "4500"
    }
];

async function initializeDummyClients() {
    try {
        // Check if clients already exist
        const existingClients = await trickleListObjects('clients', 1000, true);
        
        if (existingClients.items.length === 0) {
            // Add dummy clients
            for (const client of dummyClients) {
                await trickleCreateObject('clients', client);
            }
            console.log('Dummy clients initialized successfully');
            return true;
        }
        return false;
    } catch (error) {
        reportError(error);
        return false;
    }
}
