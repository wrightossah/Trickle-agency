const PAYSTACK_PUBLIC_KEY = 'pk_test_b6a8830d043f2d7420be7f9275209ca34535cf83';

async function initializePayment(amount, email, onSuccess) {
    try {
        const handler = window.PaystackPop.setup({
            key: PAYSTACK_PUBLIC_KEY,
            email: email,
            amount: amount * 100, // Convert to pesewas
            currency: 'GHS',
            callback: async function(response) {
                try {
                    if (response.status === 'success') {
                        await onSuccess(response);
                    } else {
                        throw new Error('Payment failed');
                    }
                } catch (error) {
                    reportError(error);
                    alert('Failed to process payment confirmation');
                }
            },
            onClose: function() {
                // Handle popup closed
            }
        });
        handler.openIframe();
        return true;
    } catch (error) {
        reportError(error);
        return false;
    }
}

async function verifyPayment(reference) {
    try {
        const response = await fetch(`https://api.paystack.co/transaction/verify/${reference}`, {
            headers: {
                'Authorization': `Bearer ${PAYSTACK_PUBLIC_KEY}`
            }
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        return await response.json();
    } catch (error) {
        reportError(error);
        return null;
    }
}
