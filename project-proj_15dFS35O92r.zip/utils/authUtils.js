async function checkAuth() {
    try {
        const token = localStorage.getItem('authToken');
        if (!token) return false;

        // First check if the session exists
        const sessionResponse = await trickleGetObject('auth-sessions', token);
        return !!sessionResponse;
    } catch (error) {
        reportError(error);
        return false;
    }
}

function logout() {
    try {
        localStorage.removeItem('authToken');
        window.location.href = '/';
    } catch (error) {
        reportError(error);
    }
}
