function formatDate(date) {
    try {
        return new Date(date).toLocaleDateString();
    } catch (error) {
        reportError(error);
        return '';
    }
}

function isExpiringSoon(date) {
    try {
        const expiryDate = new Date(date);
        const now = new Date();
        const thirtyDaysFromNow = new Date(now.setDate(now.getDate() + 30));
        return expiryDate > now && expiryDate <= thirtyDaysFromNow;
    } catch (error) {
        reportError(error);
        return false;
    }
}
